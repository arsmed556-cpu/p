package ru.example.moizametki

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import ru.example.moizametki.data.Note
import ru.example.moizametki.data.NotesDatabase

class NotesViewModel(application: Application) : AndroidViewModel(application) {
    private val noteDao = NotesDatabase.getDatabase(application).noteDao()

    val notes: Flow<List<Note>> = noteDao.observeNotes()

    fun addNote(text: String) {
        viewModelScope.launch {
            noteDao.insert(Note(text = text, timestamp = System.currentTimeMillis()))
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch { noteDao.delete(note) }
    }
}
