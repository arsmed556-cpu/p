package ru.example.moizametki.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ru.example.moizametki.NotesViewModel
import ru.example.moizametki.data.Note
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val LOG_TAG = "MoiZametki"
private val ScreenColor = Color(0xFFF6F4EF)
private val AccentColor = Color(0xFF526B54)
private val NoteColor = Color(0xFFE3EBDD)

@Composable
fun NotesApp(viewModel: NotesViewModel) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "notes") {
        composable("notes") {
            val notes by viewModel.notes.collectAsState(initial = emptyList())
            NotesScreen(
                notes = notes,
                onAddNote = viewModel::addNote,
                onDeleteNote = viewModel::deleteNote,
                onOpenNote = { note -> navController.navigate("note/${note.id}") }
            )
        }
        composable(
            route = "note/{noteId}",
            arguments = listOf(navArgument("noteId") { type = NavType.IntType })
        ) { entry ->
            val noteId = entry.arguments?.getInt("noteId") ?: return@composable
            val notes by viewModel.notes.collectAsState(initial = emptyList())
            val note = notes.firstOrNull { it.id == noteId }

            LaunchedEffect(noteId) {
                Log.d(LOG_TAG, "ID заметки на втором экране: $noteId")
            }

            NoteDetailsScreen(noteId = noteId, note = note, onBack = { navController.popBackStack() })
        }
    }
}

@Composable
private fun NotesScreen(
    notes: List<Note>,
    onAddNote: (String) -> Unit,
    onDeleteNote: (Note) -> Unit,
    onOpenNote: (Note) -> Unit
) {
    var text by rememberSaveable { mutableStateOf("") }
    var noteToDelete by remember { mutableStateOf<Note?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(ScreenColor),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Мои заметки",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF27352A)
                )
                Text(
                    text = "Запишите то, что важно не забыть.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color(0xFF667268)
                )
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Текст заметки") },
                    placeholder = { Text("Например, купить продукты") },
                    minLines = 3,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentColor,
                        focusedLabelColor = AccentColor,
                        cursorColor = AccentColor
                    )
                )
                Button(
                    onClick = {
                        Log.d(LOG_TAG, "Текст из поля ввода: $text")
                        if (text.isNotBlank()) {
                            onAddNote(text.trim())
                            text = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentColor)
                ) {
                    Text("Сохранить заметку", fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Список заметок",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF27352A)
                )
            }
        }

        if (notes.isEmpty()) {
            item {
                Text(
                    text = "Здесь пока пусто. Добавьте первую заметку выше.",
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = Color(0xFF667268)
                )
            }
        } else {
            items(notes, key = Note::id) { note ->
                Card(
                    onClick = { onOpenNote(note) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = NoteColor)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = formatTimestamp(note.timestamp),
                                style = MaterialTheme.typography.labelMedium,
                                color = AccentColor
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = note.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color(0xFF27352A)
                            )
                        }
                        TextButton(onClick = { noteToDelete = note }) {
                            Text("Удалить", color = Color(0xFF9A3C35))
                        }
                    }
                }
            }
        }
    }

    val selectedNote = noteToDelete
    if (selectedNote != null) {
        AlertDialog(
            onDismissRequest = { noteToDelete = null },
            title = { Text("Удалить заметку?") },
            text = { Text("Заметка будет удалена без возможности восстановления.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteNote(selectedNote)
                    noteToDelete = null
                }) {
                    Text("Удалить", color = Color(0xFF9A3C35))
                }
            },
            dismissButton = {
                TextButton(onClick = { noteToDelete = null }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
private fun NoteDetailsScreen(noteId: Int, note: Note?, onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().background(ScreenColor).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TextButton(onClick = onBack) {
            Text("← Все заметки", color = AccentColor)
        }
        Text(
            text = "Заметка №$noteId",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF27352A)
        )
        if (note == null) {
            Text("Заметка не найдена.", color = Color(0xFF667268))
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NoteColor)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = formatTimestamp(note.timestamp),
                        style = MaterialTheme.typography.labelLarge,
                        color = AccentColor
                    )
                    Text(text = note.text, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

private fun formatTimestamp(timestamp: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(timestamp))
